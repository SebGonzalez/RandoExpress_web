import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rando-form',
  templateUrl: './rando-form.component.html',
  styleUrls: ['./rando-form.component.css']
})
export class RandoFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

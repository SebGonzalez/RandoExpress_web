export class Personne {
  constructor(public id: string, public mail: string, public type: string) {
  }
}

export class Rando {
  constructor() {
  }
}
